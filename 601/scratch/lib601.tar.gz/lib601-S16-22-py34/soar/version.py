#!/usr/bin/python
################################soar/version.py#################################
# soar3.500
#  / version.py
# (C) 2006-2008 Michael Haimes
#
# Protected by the GPL
#
#
# ...
# Go ahead, try and sue me
################################################################################

####################################Imports#####################################
from lib601.version import version

def format_version():  return version
