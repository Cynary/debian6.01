import math
dimensions(8,2)
initialRobotLoc(0.5, 0.5, math.pi/12)
