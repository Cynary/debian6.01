initialRobotLoc(2.32376, 1.5)
dimensions(3.0, 3.0)


