initialRobotLoc(1.64376, 1.5)
dimensions(3.0, 3.0)


