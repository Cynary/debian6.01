#!/usr/bin/env python

try:
	from setuptools import setup
except ImportError as e:
	from distutils.core import setup

from lib601.version import version

import sys
executable = 'py%s' % ''.join(map(str, sys.version_info[:2]))

setup(name='lib601',
      version='%s-%s' % (version, executable),
      description='6.01 Code Distribution',
      author='6.01 Staff',
      author_email='6.01-staff@mit.edu',
      url='http://mit.edu/6.01/',
      packages = ['lib601','form','soar','soar.io','soar.graphics','soar.serial','soar.controls','soar.outputs','soar.serial.tools'],
      package_data={'lib601': ['*.pyc','sigFiles/*'],'soar': ['media/*','worlds/*']},
      scripts=['installsoar.py', 'lib601/CMax','soar/soar'],
     )
